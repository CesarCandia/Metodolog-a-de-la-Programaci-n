#include <iostream>

using namespace std;
int main(int argc, char** argv) 
{
	
	
	
	int num=0, i=0;
	
	
	cout<< "Por favor ingrese un numero." << endl;
	cin>> num;
	
	for (int i=num; num>=0; num--)
	{
		cout<<"Restante: "<< num << endl;
	}
	
	
	
	
	return 0;
}
