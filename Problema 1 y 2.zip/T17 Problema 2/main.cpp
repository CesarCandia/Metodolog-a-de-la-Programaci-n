#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	
	
	int i=1;
	
	
	cout<< "Estos son los numeros pares entre 1 y 100." << endl;
	
	
	for (int i=1; i<=100; i++)
	{
		if (i%2==0)
		{
			cout<< i << endl;	
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
