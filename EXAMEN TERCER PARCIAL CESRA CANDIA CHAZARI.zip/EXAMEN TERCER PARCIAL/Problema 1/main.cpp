#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	float num1=0, num2=0;
	
	
	
	//Bienvenida al programa.
	cout << "\n\nBienveido al programa para ver si dos numeros son IGUALES o DIFERENTES.\n" << endl;
	
	
	//Pide el primer n�mero a ingresar.
	do 
	{
		cout << "\nIngrese el primer numero." << endl;
		cin>> num1;
	} while (num1 <=0 || num1 >= 1000);
	
	//Pide el segundo n�mero a ingresar.
	do 
	{
		cout << "\nIngrese el segundo numero." << endl;
		cin>> num2;
	} while (num2 <=0 || num2 >= 1000);
	
	//Calcula cual n�mero es igual y cual es diferente.
	if (num1==num2)
	{
		cout << "\n**********************" << endl;
		cout << "*****SON IGUALES******" << endl;
		cout << "**********************" << endl;
	}
	else 
	{
		cout << "\n**********************" << endl;
		cout << "****SON DIFERENTES****" << endl;
		cout << "**********************" << endl;
	}
	
	
	return 0;
}
