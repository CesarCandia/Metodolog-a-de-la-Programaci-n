#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	
	int cal1, cal2, cal3, cal4, cal5, cal6, cal7, cal8, cal9, cal10;
	string nombre1="", nombre2="", nombre3="", nombre4="", nombre5="", nombre6="", nombre7="", nombre8="", nombre9="", nombre10="";
	
	
	
	//INTRUCCIONES.
	cout << "\n****************************************************************\n" << endl;	
	cout << "Ingrese 10 calificaciones y 10 nombres de alumnos distintos." << endl;
	cout << "\n****************************************************************\n" << endl;		
		
	
	//INGRESE LOS NOMBRES.
	cout << "\n*********************************************" << endl;	
	cout << "Ingrese el nombre de 10 alumnos diferentes." << endl;
	cin>> nombre1>>nombre2>>nombre3>>nombre4>>nombre5>>nombre6>>nombre7>>nombre8>>nombre9>>nombre10;	
		
		
		
	//INGRESE LAS CALIFICACIONES.
	
	cout << "\n***************************************************" << endl;
	cout << "Ingrese la calificacion de 10 alumnos diferentes.\n" << endl;
	
	do 
	{
		cout << "Calificacion 1:" << endl;
		cin>> cal1;
	
	} while (cal1 <= 0 || cal1 >= 11);
	
	do 
	{
		cout << "Calificacion 2:" << endl;
		cin>> cal2;
	} while (cal2 <= 0 || cal2 >= 11);
	
	do 
	{
		cout << "Calificacion 3:" << endl;
		cin>> cal3;
	} while (cal3 <= 0 || cal3 >= 11);
	
	do 
	{
		cout << "Calificacion 4:" << endl;
		cin>> cal4;
	} while (cal4 <= 0 || cal4 >= 11);
	
	do 
	{
		cout << "Calificacion 5:" << endl;
		cin>> cal5;
	} while (cal5 <= 0 || cal5 >= 11);
	
	do 
	{
		cout << "Calificacion 6:" << endl;
		cin>> cal6;
	} while (cal6 <= 0 || cal6 >= 11);
	
	do 
	{
		cout << "Calificacion 7:" << endl;
		cin>> cal7;
	} while (cal7 <= 0 || cal7 >= 11);
	
	do 
	{
		cout << "Calificacion 8:" << endl;
		cin>> cal8;
	} while (cal8 <= 0 || cal8 >= 11);
	
	do 
	{
		cout << "Calificacion 9:" << endl;
		cin>> cal9;
	} while (cal9 <= 0 || cal9 >= 11);
	
	do 
	{
		cout << "Calificacion 10:" << endl;
		cin>> cal10;
	} while (cal10 <= 0 || cal10 >= 11);
	
	
	
	
	
	

	//DETERMINA SI EL ALUMNO ES MALO, REGULAR O BUENO.
	
	//NOMBRE 1 AND CAL1
	if (cal1 >=0 && cal1 <=6)
	{
		cout << "El alumno " << nombre1 << " es Malo." <<endl;
	}
	else 
	{
		if (cal1 >=7 && cal1 <=8)
		{
			cout << "El alumno "<< nombre1 << " es Regular." << endl;
		}
		else
		{
			if (cal1 >=9 && cal1 <=10)
			{
				cout << "El alumno " << nombre1 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
    //NOMBRE 2 AND CAL2
    if (cal2 >=0 && cal2 <=6)
	{
		cout << "El alumno " << nombre2 << " es Malo." <<endl;
	}
	else 
	{
		if (cal2 >=7 && cal2 <=8)
		{
			cout << "El alumno "<< nombre2 << " es Regular." << endl;
		}
		else
		{
			if (cal2 >=9 && cal2 <=10)
			{
				cout << "El alumno " << nombre2 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 3 AND CAL3
    if (cal3 >=0 && cal3 <=6)
	{
		cout << "El alumno " << nombre3 << " es Malo." <<endl;
	}
	else 
	{
		if (cal3 >=7 && cal3 <=8)
		{
			cout << "El alumno "<< nombre3 << " es Regular." << endl;
		}
		else
		{
			if (cal3 >=9 && cal3 <=10)
			{
				cout << "El alumno " << nombre3 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 4 AND CAL4
    if (cal4 >=0 && cal4 <=6)
	{
		cout << "El alumno " << nombre4 << " es Malo." <<endl;
	}
	else 
	{
		if (cal4 >=7 && cal4 <=8)
		{
			cout << "El alumno "<< nombre4 << " es Regular." << endl;
		}
		else
		{
			if (cal4 >=9 && cal4 <=10)
			{
				cout << "El alumno " << nombre4 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 5 AND CAL5
    if (cal5 >=0 && cal5 <=6)
	{
		cout << "El alumno " << nombre5 << " es Malo." <<endl;
	}
	else 
	{
		if (cal5 >=7 && cal5 <=8)
		{
			cout << "El alumno "<< nombre5 << " es Regular." << endl;
		}
		else
		{
			if (cal5 >=9 && cal5 <=10)
			{
				cout << "El alumno " << nombre5 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 6 AND CAL6
    if (cal6 >=0 && cal6 <=6)
	{
		cout << "El alumno " << nombre6 << " es Malo." <<endl;
	}
	else 
	{
		if (cal6 >=7 && cal6 <=8)
		{
			cout << "El alumno "<< nombre6 << " es Regular." << endl;
		}
		else
		{
			if (cal6 >=9 && cal6 <=10)
			{
				cout << "El alumno " << nombre6 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 7 AND CAL7
    if (cal7 >=0 && cal7 <=6)
	{
		cout << "El alumno " << nombre7 << " es Malo." <<endl;
	}
	else 
	{
		if (cal7 >=7 && cal7 <=8)
		{
			cout << "El alumno "<< nombre7 << " es Regular." << endl;
		}
		else
		{
			if (cal7 >=9 && cal7 <=10)
			{
				cout << "El alumno " << nombre7 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 8 AND CAL8
    if (cal8 >=0 && cal8 <=6)
	{
		cout << "El alumno " << nombre8 << " es Malo." <<endl;
	}
	else 
	{
		if (cal8 >=7 && cal8 <=8)
		{
			cout << "El alumno "<< nombre8 << " es Regular." << endl;
		}
		else
		{
			if (cal8 >=9 && cal8 <=10)
			{
				cout << "El alumno " << nombre8 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 9 AND CAL9
    if (cal9 >=0 && cal9 <=6)
	{
		cout << "El alumno " << nombre9 << " es Malo." <<endl;
	}
	else 
	{
		if (cal9 >=7 && cal9 <=8)
		{
			cout << "El alumno "<< nombre9 << " es Regular." << endl;
		}
		else
		{
			if (cal9 >=9 && cal9 <=10)
			{
				cout << "El alumno " << nombre9 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	//NOMBRE 10 AND CAL10
    if (cal10 >=0 && cal10 <=6)
	{
		cout << "El alumno " << nombre10 << " es Malo." <<endl;
	}
	else 
	{
		if (cal10 >=7 && cal10 <=8)
		{
			cout << "El alumno "<< nombre10 << " es Regular." << endl;
		}
		else
		{
			if (cal10 >=9 && cal10 <=10)
			{
				cout << "El alumno " << nombre10 << " es Bueno." << endl;
			}
			else
			{
				cout << "Numero no valido." << endl;
			}
		}
	}
	
	return 0;
}
