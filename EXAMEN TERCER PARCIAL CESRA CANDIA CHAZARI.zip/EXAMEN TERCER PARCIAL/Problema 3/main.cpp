#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	
	float num1=0, num2=0, i=0;
	
	
	
	//PIDE EL PRIMER NUMERO A LEER.
	do 
	{
		cout << "\n\nIngrese el primer numero." << endl;
		cin>> num1;
	} while (num1 <=0 || num1 >100);
	
	
	//PIDE EL SEGUNDO NUMERO A LEER.
	do 
	{
		cout << "\n\nIngrese el segundo numero." << endl;
		cin>> num2;
	} while (num2 <=0 || num2 >100);
	
	
	
	//DETERMINA QUE NUMERO ES MAYOR.
	if (num1>num2)
	{
		cout << "\n\nEl numero mayor es: " << num1 << endl;
		cout << "El numero menor es: " << num2 << endl;
		
		cout << "\nEl rango de valores es: \n" << endl;
		for (int i=num1; i>=num2; i--)
		{
		cout << i << endl;
		}
		
	}
	else
	{
		cout << "\n\nEl numero mayor es: " << num2  << endl;
		cout << "El numero menor es: " << num1 << endl;
		
		cout << "\nEl rango de valores es: \n" << endl;
		for (int i=num2; i>=num1; i--)
		{
		cout << i << endl;
		}
		
	}
	
	
	
	

	
	return 0;
}
