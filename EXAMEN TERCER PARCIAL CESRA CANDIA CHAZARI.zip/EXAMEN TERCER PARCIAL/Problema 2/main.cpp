#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	
	
	int num;
	
	
	//INTRUCCION PRINCIPAL PEDIR EL NUMERO.
	cout << "\nIngrese un numero entero.\n" << endl;
	cin >> num;
	
    if(num%2==0)
	{
        cout << "\nEl numero es par debe ser impar.\n" << endl;
    }
	else
	{
        cout << "\nEl numero es impar." << endl;;
        //DETERMINA CUANDO UN NUMERO ES POSITIVO O NEGATIVO.
        if (num < 0)
		{
		cout << "\nEl numero es negativo.\n" << endl;
		}
		else 
		{
		cout << "\nEl numero es positivo.\n" << endl;
		}
    }	
	

	return 0;
}
