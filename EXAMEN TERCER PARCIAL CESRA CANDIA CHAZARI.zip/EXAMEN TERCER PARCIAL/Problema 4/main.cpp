#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{

    int num[5] = {0,0,0,0,0}, x=0, i=0, temp;
    
    
	//INSTRUCCION GENERAL.
	cout << "\n******************************" << endl;
	cout << "\n Ingrese 5 numeros pares: \n" << endl;
	cout << "******************************\n" << endl;
	
    //GUARDAR EL NUMERO EN LA MATRIZ Y LUEGO COMPROBARLO.
    
	int temp_num=0, bandera =-1;

  
    //LEE LOS 5 NUMEROS PARES.
	for (x=0; x<5; x++)
	{
	    //FLAG REGRESA A ESTADO ORIGINAL.
		bandera = -1;
		
		do
		{
		    //LA FLAG REGRESA A ESTADO ORIGINAL.
		    bandera = -1;	
			
			//PEDIMOS INGRESAR LOS 5 NUMEROS.	
			cout << "\n--------------------------------" << endl;
		    cout << "Ingrese los numeros seguidos... " << endl;
		    cin >> temp_num; 
			
			//COMPROBAR SI EL NUMERO ES "IMPAR"
			
			if (temp_num % 2 == 1)   
		    {
		    	cout << "\n*****************************************************************" << endl;
		        cout << "Numero ingresado es impar, ingrese nuevamente un numero valido." << endl;
		        cout << "*****************************************************************\n" << endl;
	    	}
		    else
	    	{
	    	
	            //CON EL FOR COMPROBAMOS SI EL NUMERO ESTA EN LA MATRIZ.	
		        for(int p = 0; p<5; p++)
			    {
				    if( temp_num == num[p])
			    	{
			    		bandera = 1;
			    	}
		        }
					
				if(bandera == 1)
				{
					cout << "\n*****************************************************************" << endl;
					cout << "Numero ingresado es repetido, ingrese nuevamente otro numero." << endl;
					cout << "*****************************************************************\n" << endl;
				}
				else
				{
					//SI NO ES REPETIDO EL NUMERO LO DEPOSITAMOS EN LA MATRIZ.
					num[x] = temp_num;
					
					cout << "\n---------------------" << endl;
					cout <<"Numero guardado...\n" << endl;
					
					//EL FOR VERIFICA SI LOS VALORES SON ALMACENADOS EN LA MATRIZ.
					for(int p = 0; p<5; p++)
					{
						cout << num[p] << "" << endl;
					}
				}
			}
		}while(temp_num % 2 == 1 || bandera == 1);	
				
	}
				
	
	//FOR PARA CALCULAR DE MAYOR A MENOR LOS NUMEROS.
	for (x=0; x<=4; x++)
	{
		for (i=0; i<=3; i++)
		{
			if(num[i] > num[i+1])
			{
				temp = num[i];
				num[i] = num[i+1];
				num[i+1] = temp;
			}
	    }
	}
	    
	
    //SALIDA DE DATOS ORDENADOS DE MAYOR A MENOR.
    cout << "\n\n\n***************************" << endl;
	cout << "Numeros ordenados: \n" << endl;
	
	for (x=4; x>=0; x--)
	{
	    cout << num[x] << endl;
	}
	




	return 0;
}
