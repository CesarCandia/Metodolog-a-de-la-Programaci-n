#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	
	
	int num, i, cuadrado;
	
	cout << "\n******************************************************\n" << endl;
	cout << "Bienvenido a calcular el cuadrado de un numero." << endl;
	cout << "Tome en cuenta que solo acepta numeros POSITIVOS." << endl;
	cout << "Si ingresa un numero NEGATIVO se detendra el programa." << endl;
	cout << "\n******************************************************\n" << endl;
	
	
	
	do
	{
		//PIDE EL NUMERO PRINCIPAL.
		cout << "\n**********************" << endl;
		cout << "Ingrese un numero." << endl;
		cin >> num;
		cout << "**********************\n" << endl;
		cuadrado=num*num;
		cout << "El cuadrado es: " << cuadrado << "\n" << endl;
		
	} while (num >=0);
	
	return 0;
}
