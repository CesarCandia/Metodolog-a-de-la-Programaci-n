#include <iostream>
#include <string>

using namespace std;
int main(int argc, char** argv) 
{
	
	string nombre="", grupo="", lic="", fecha="";
	float puntaje=0, aciertos=0, bajas=0, promedio=0;
	
	
	
	//APARTADO DE DATOS.
	cout << "************************" << endl;
	cout << "\nIngrese su nombre." << endl;
	cin>> nombre;
	
	cout << "Ingrese su grupo." << endl;
	cin>> grupo;
	
	cout << "Ingrese su licenciatura." << endl;
	cin>> lic;
	
	cout << "Ingrese la fecha." << endl;
	cin>> fecha;
	cout << "\n************************" << endl;
	
	
	
	//BIENVENIDA AL EXAMEN.
	cout << "\nBienvenido al examen: " << nombre << "\nEres de la Licienciatura en: " << lic << "\nTu grupo es: " << grupo << "\nHoy es: " << fecha << "\n\n"<< endl;
	
	
	
	
	//INICIO
	cout << "Usted tiene un puntaje de: 0\n\n" << endl;
	puntaje=0;
		
	//APARTADO DE PREGUNTAS.
	
	
	string opc="", z="", d="", Z="", D="";
	
	do {
		cout << "1. �Cual es la sentencia de entrada en C++?" << endl; 
		cout << "\na) string. \nb) cout. \nc) cin.\n" << endl;
		
		cin>> opc;	
	} while (opc<="Z" &&  opc>="D" &&  opc<="d" && opc>="z");
	//OPCI�N SI ENTONCES.
	if (opc=="c")
	{
		puntaje+=2;
	}
	else 
	{
		bajas+=1;
	}
	
	
	
	
	
	
	do {
		cout << "\n2. �Que significa los dos mas de C++?" << endl;
		cout << "\na) Decremento de C. \nb) Incremento de C. \nc) Manupulacion de C.\n" << endl;
		cin>> opc;
			
	} while (opc<="Z" &&  opc>="D" &&  opc<="d" && opc>="z");
	//OPCI�N SI ENTONCES.
	if (opc=="b")
	{
		puntaje+=2;
	}
	else 
	{
		bajas+=1;	
	}
	
	
	
	
	
	do {
		cout << "\n3. �Cual es la sentencia de salida en C++?"<< endl;
		cout << "\na) cout. \nb) float. \nc) cin.\n" << endl;
		cin>> opc;
				
	} while (opc<="Z" &&  opc>="D" &&  opc<="d" && opc>="z");
	//OPCI�N SI ENTONCES.
	if (opc=="a")
	{
		puntaje+=2;
	}
	else 
	{
		bajas+=1;
	}
	
	
	
	
	
	
	
	do {
		cout << "\n4. �Cual es la sentencia para ingresar datos enteros?" << endl;
		cout << " \na) char. \nb) int. \nc) float.\n" << endl;
		cin>> opc;	
		
	} while (opc<="Z" &&  opc>="D" &&  opc<="d" && opc>="z");	
	//OPCI�N DE SI ENTONCES.
	if (opc=="b")
	{
		puntaje+=2;
	}
	else 
	{
		bajas+=1;
	}
	
	
	
	
	
	
	do {
		cout << "\n5. �Que es namespace?" << endl;
		cout << " \na) Organizar clases dentro de su entorno. \nb) Metodo de union. \nc) Agrupacion.\n" << endl;
		cin>> opc;
			
	} while (opc<="Z" &&  opc>="D" &&  opc<="d" && opc>="z");
	//OPCI�N DE SI ENTONCES.
	if (opc=="a")
	{	
		puntaje+=2;
	}
	else 
	{
		bajas+=1;
	}
	
   

    cout << "\n\n\n*****************************************************" << endl;
    aciertos=puntaje/2;
	cout << "Usted obtuvo: " << aciertos << " preguntas correctas." << endl;
	cout << "Usted obtuvo: " << bajas << " preguntas malas." << endl;	
	cout << "Usted obtuvo: " << puntaje << " puntaje final." << endl;
	promedio=puntaje/5;
	cout << "Usted obtuvo: " << promedio << " promedio final." << endl;
	 cout << "*****************************************************" << endl;
	

	
		
	return 0;
}







