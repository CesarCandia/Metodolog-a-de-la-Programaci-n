#include <iostream>
#include <string>

using namespace std;
int main(int argc, char** argv) 
{
	
	string viaje="", nacimiento="", nombre="";
	
	
	cout << "Ingrese su nombre." << endl;
	cin>> nombre;
	cout << "Ingrese su fecha de nacimiento." << endl;
	cin>> nacimiento;
	cout << "Ingrese el pais donde quisiera viajar.\n**SIN ESPACIOS***" << endl;
	cin>> viaje;
	
	
	cout << "\n\nUsted es " << nombre << " y nacio el dia " << nacimiento << " asi mismo quisiera viajar a " << viaje << "." << endl;
	
	return 0;
}
