#include <iostream>
#include <string>

using namespace std;
int main(int argc, char** argv) 
{
	
	string pais="", mascota="", materia="", nombre="";
	
	cout << "Ingrese su nombre." << endl;
	cin>> nombre;
	cout << "Ingrese el nombre de su mascota." << endl;
	cin>> mascota;
	cout << "Ingrese el nombre del pais donde vive." << endl;
	cin>> pais;
	
	cout << "\n\nUsted es " << nombre << " su mascota se llama " << mascota << " y vive en " << pais << endl;
	
	
	
	return 0;
}
