#include <iostream>

using namespace std;
int main(int argc, char** argv) 
{
	
	float mt=0,P=0,Y=0,M=0;
	
	do 
	{
		cout<< "\n\nIngrese la cantidad de metros a convertir."<< endl;
		cout<< "Minimo 1 metro maximo 1000 metros.\n"<< endl;
		cout<< "Se calculara Pies, Yardas y Millas a la ves."<< endl;
		cin>> mt;	
	} while (mt <= 0 || mt >= 1001);
	
	P=mt*3.28084;
	cout<< "\n\nMetros a Pies equivale a: "<< P << endl;
	Y=mt*1.09361;
	cout<< "Metros a Yardas equivale a: "<< Y << endl;
	M=mt*0.000621371;
	cout<< "Metros a Millas equivale a: "<< M << endl;
	
	
	
	
	return 0;
}
