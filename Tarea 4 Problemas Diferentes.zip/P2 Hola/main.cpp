#include <iostream>
#include <windows.h>

using namespace std;
int main(int argc, char** argv) 
{
	int seg=0;
	
	
	do {
		cout<<"Ingrese los segundos deseados de 30 segundos a 120 segundos."<< endl;
		cin>> seg;
	} while (seg <= 29 || seg >= 121);
		
		for (int m=seg-1; m>=0; m--){
			for (int s=59; s>=0; s--){
				cout<< m <<":"<< s << endl;
				cout<<"Hola"<< endl;
				cout<<"Sonando"<< endl;
			}
		}
	
	
	
	
	
	
	return 0;
}
