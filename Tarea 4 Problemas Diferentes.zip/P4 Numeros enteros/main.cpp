#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	int num=0;
	
	do{
		cout<< "Ingrese un numero del 1 al 10"<< endl;
		cin>> num;
	} while (num <= 0 || num >= 11);
	
	//Funci�n FOR.
	
	for (int m=num-1; m>=0; m--){
		for (int s=59; s>=0; s--){
			cout << m <<":"<< s << endl;
		}	
	}
	
	cout<< "Se termino el tiempo."<< endl;
		
	
	return 0;
}
