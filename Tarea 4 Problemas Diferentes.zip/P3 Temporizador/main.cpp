#include <iostream>


using namespace std;
int main(int argc, char** argv) 
{
	int min=0,seg=0;
	
	cout<< "Ingrese los minutos deseados."<< endl;
	cin>> min;
	cout<< "Ingrese los segundos deseados."<< endl;
	cin>> seg;
	
	//Funci�n FOR.
	for (int a=min-1; a>=0; a--){
		for (int b=seg; b>=0; b--){
			cout<< a <<":"<< b << endl;
		}
	}
	cout<< "Fin del tiempo."<< endl;
		
	
	return 0;
}
